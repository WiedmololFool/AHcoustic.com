<?php
$mysql = new mysqli("127.0.0.1:3306", "kursach101", 'Fingerstyle228', "kursach101");
$value1 = 1;
if ($mysql->connect_error)
{
    echo('Error number: ' . $mysql->connect_errno . '<br>');
    die('Error: ' . $mysql->connect_error);
}
